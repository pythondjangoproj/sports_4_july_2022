from django.db import models
# from django.conf import settings
# from django.contrib.auth.models import User
from iconApi.settings import default
from IGL_account.models import User
from iconApi.models import BaseModel
from iconApi.mixins import AuditTrailMixin, GuidFieldMixin, NameDescriptionMixin
from games.models import Platform, Game


class ChallengeStatus(BaseModel,
                      NameDescriptionMixin):
    class Meta:
        verbose_name_plural = 'Challenge status options'

    def __str__(self):
        return self.name


class Challenge(BaseModel,
                GuidFieldMixin,
                AuditTrailMixin):
    status = models.ForeignKey(ChallengeStatus, on_delete=models.CASCADE, default=default.DEFAULT_CHALLENGE_STATUS)
    entry_fee = models.PositiveSmallIntegerField()
    challenger = models.ForeignKey(User, blank=True, null=True, on_delete=models.CASCADE, related_name="challenger")
    recipient = models.ForeignKey(User, blank=True, null=True, on_delete=models.CASCADE, related_name="recipient")
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    platforms = models.ManyToManyField(Platform)
    is_open = models.BooleanField(default=False)

    sent_at = models.DateTimeField()
    responded_at = models.DateTimeField(blank=True, null=True)

    @property
    def outcome(self):
        try:
            o = ChallengeOutcome.objects.get(challenge=self)
            return o
        except ChallengeOutcome.DoesNotExist:
            return None

    @property
    def is_direct(self):
        return True if self.recipient and not self.is_open else False

    @property
    def is_accepted(self):
        return True if self.responded_at \
                       and self.status.id == default.CHALLENGE_ACCEPTED_STATUS else False

    @property
    def is_refused(self):
        return True if self.responded_at \
                       and self.status.id == default.CHALLENGE_REFUSED_STATUS else False

    @property
    def is_canceled(self):
        return True if self.responded_at \
                       and self.status.id == default.CHALLENGE_CANCELED_STATUS else False

    @property
    def has_response(self):
        return True if self.recipient and self.responded_at else False

    @property
    def total_winnings(self):
        if self.outcome:
            return self.outcome.total_winnings

    def __str__(self):
        if self.challenger and self.recipient:
            return "{0} - {1} vs. {2}".format(self.game,
                                              self.challenger.username,
                                              self.recipient.username)
        return "{0} - {1}".format(self.game,
                                  self.challenger.username)


class ChallengeOutcome(BaseModel,
                       GuidFieldMixin):
    challenge = models.OneToOneField(Challenge, on_delete=models.CASCADE)
    winner = models.ForeignKey(User, on_delete=models.SET_NULL, blank=True, null=True)
    submitted_at = models.DateTimeField()

    @property
    def total_winnings(self):
        return self.challenge.entry_fee * 2

    @property
    def get_winner(self):
        return "{0}".format(self.winner.username)

    def __str__(self):
        return "{0} (Winner: {1}) ".format(self.challenge, self.winner.username)


class GameMode(BaseModel,
               NameDescriptionMixin):
    class Meta:
        verbose_name_plural = 'Game mode options'

    def __str__(self):
        return self.name


class DirectChallenge(BaseModel,
                      GuidFieldMixin,
                      AuditTrailMixin):
    platforms = models.ManyToManyField(Platform)
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    Opponent = models.ForeignKey(User, blank=True, null=True, on_delete=models.CASCADE)
    entry_fee = models.PositiveSmallIntegerField()
    game_mode = models.ForeignKey(GameMode, on_delete=models.CASCADE, default=default.DEFAULT_OPEN_CHALLENGE_STATUS)

    def __str__(self):
        return str(self.Opponent)


class Opponent(BaseModel,
               NameDescriptionMixin):
    class Meta:
        verbose_name_plural = 'opponent default option'

    def __str__(self):
        return self.name


class OpenChallenge(BaseModel,
                    GuidFieldMixin,
                    AuditTrailMixin):
    platforms = models.ManyToManyField(Platform)
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    opponent = models.ForeignKey(Opponent, on_delete=models.CASCADE, default=default.DEFAULT_OPEN_CHALLENGE_STATUS)
    entry_fee = models.PositiveSmallIntegerField()
    game_mode = models.ForeignKey(GameMode, on_delete=models.CASCADE, default=default.DEFAULT_OPEN_CHALLENGE_STATUS)

    def __str__(self):
        return str(self.opponent)


class SelectChallenge(BaseModel,
                      NameDescriptionMixin):
    class Meta:
        verbose_name_plural = 'select challenge option'

    def __str__(self):
        return self.name


class CreateChallenge(BaseModel,
                      GuidFieldMixin,
                      AuditTrailMixin):
    platforms = models.ManyToManyField(Platform)
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    status = models.ForeignKey(SelectChallenge, on_delete=models.CASCADE, default=default.DEFAULT_OPEN_CHALLENGE_STATUS)
    entry_fee = models.PositiveSmallIntegerField()
    Opponent = models.ForeignKey(User, blank=True, null=True, on_delete=models.CASCADE)
    game_mode = models.ForeignKey(GameMode, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.Opponent)

