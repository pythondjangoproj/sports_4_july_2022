from django.shortcuts import render
from .models import Challenge, ChallengeOutcome, DirectChallenge, OpenChallenge, CreateChallenge
from .serializers import ChallengeSerializer, CreateChallengeSerializer, ChallengeOutcomeSerializer, \
    CreateChallengeOutcomeSerializer, DirectChallengeSerializer, CreateDirectChallengeSerializer, \
    OpenChallengeSerializer, CreateOpenChallengeSerializer, CreateNewChallengeSerializer
from django_filters import rest_framework as filters
from django.utils import timezone
from iconApi.settings import default
from rest_framework.response import Response
from rest_framework import generics
from rest_framework.decorators import action
from rest_framework import status, permissions, viewsets


# # Create your views here.
# class IsChallengeRecipient(permissions.BasePermission):
#
#     def has_object_permission(self, request, view, obj):
#         if request.method in permissions.SAFE_METHODS:
#             return True
#
#         # User must be the recipient of the challenge in order to accept/refuse
#         return obj.recipient == request.user
#
#
# class IsChallengeCreator(permissions.BasePermission):
#
#     def has_object_permission(self, request, view, obj):
#         # Read permissions are allowed to any request,
#         # so we'll always allow GET, HEAD or OPTIONS requests.
#         if request.method in permissions.SAFE_METHODS:
#             return True
#
#         # The User must be the creator of the challenge in order to cancel
#         return obj.challenger == request.user
#
#
# class ChallengeViewSet(viewsets.ModelViewSet):
#     queryset = Challenge.objects.all()
#     serializer_class = ChallengeSerializer
#     filter_backends = [filters.DjangoFilterBackend, ]
#     filterset_class = ChallengeFilter
#
#     @action(detail=True, methods=['post'], permission_classes=[IsChallengeRecipient])
#     def accept(self, request, pk=None):
#         challenge = self.get_object()
#         serializer = ChallengeResponseSerializer(data=request.data)
#         if serializer.is_valid():
#             challenge.responded_at = timezone.now()
#             challenge.status = ChallengeStatus.objects.get(id=default.CHALLENGE_ACCEPTED_STATUS)
#             challenge.save()
#             return Response({'status': 'challenge_accepted'})
#         else:
#             return Response(serializer.errors,
#                             status=status.HTTP_400_BAD_REQUEST)
#
#     @action(detail=True, methods=['post'], permission_classes=[IsChallengeRecipient])
#     def refuse(self, request, pk=None):
#         challenge = self.get_object()
#         serializer = ChallengeResponseSerializer(data=request.data)
#         if serializer.is_valid():
#             challenge.responded_at = timezone.now()
#             challenge.status = ChallengeStatus.objects.get(id=default.CHALLENGE_REFUSED_STATUS)
#             challenge.save()
#             return Response({'status': 'challenge_refused'})
#         else:
#             return Response(serializer.errors,
#                             status=status.HTTP_400_BAD_REQUEST)
#
#     @action(detail=True, methods=['post'], permission_classes=[IsChallengeCreator])
#     def cancel(self, request, pk=None):
#         challenge = self.get_object()
#         serializer = ChallengeResponseSerializer(data=request.data)
#         if serializer.is_valid():
#             challenge.responded_at = timezone.now()
#             challenge.status = ChallengeStatus.objects.get(id=default.CHALLENGE_CANCELED_STATUS)
#             challenge.save()
#             return Response({'status': 'challenge_canceled'})
#         else:
#             return Response(serializer.errors,
#                             status=status.HTTP_400_BAD_REQUEST)
#
#
# class ChallengeOutcomeViewSet(viewsets.ModelViewSet):
#     queryset = ChallengeOutcome.objects.all()
#     serializer_class = ChallengeOutcomeSerializer


class UserChallengeAPI(generics.GenericAPIView):
    serializer_class = CreateChallengeSerializer

    def post(self, request):
        """Create List of record for challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the user platform"})

    def get(self, request, pk=None):
        """return a list of all challenges for on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserPlatform id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = Challenge.objects.get(id=user_id)
                serializer = ChallengeSerializer(user, many=True)
                return Response({"data": serializer.data})
            user = Challenge.objects.all()
            serializer = ChallengeSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of user challenge "})


class UserChallengeResultAPI(generics.GenericAPIView):
    serializer_class = ChallengeOutcomeSerializer

    def post(self, request):
        """Create List of record for challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateChallengeOutcomeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the user challenge result"})

    def get(self, request, pk=None):
        """return a list of all challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = ChallengeOutcome.objects.get(id=user_id)
                serializer = ChallengeOutcomeSerializer(user, many=True)
                return Response({"data": serializer.data})
            user = ChallengeOutcome.objects.all()
            serializer = ChallengeOutcomeSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of challenge winner "})


class DirectChallengeAPI(generics.GenericAPIView):
    serializer_class = CreateDirectChallengeSerializer

    def post(self, request):
        """Create List of record for direct challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateDirectChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the direct challenge"})

    def get(self, request, pk=None):
        """return a list of all direct challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = DirectChallenge.objects.get(id=user_id)
                serializer = DirectChallengeSerializer(user, many=True)
                return Response({"data": serializer.data})
            user = DirectChallenge.objects.all()
            serializer = DirectChallengeSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of direct challenge"})


class OpenChallengeAPI(generics.GenericAPIView):
    serializer_class = CreateOpenChallengeSerializer

    def post(self, request):
        """Create List of record for open challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateOpenChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the open challenge"})

    def get(self, request, pk=None):
        """return a list of all direct challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = OpenChallenge.objects.get(id=user_id)
                serializer = OpenChallengeSerializer(user, many=True)
                return Response({"data": serializer.data})
            user = OpenChallenge.objects.all()
            serializer = OpenChallengeSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of open challenge"})


class CreateNewChallengeAPI(generics.GenericAPIView):
    serializer_class = CreateNewChallengeSerializer

    def post(self, request):
        """Create List of record for challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateOpenChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the new challenge"})

    def get(self, request, pk=None):
        """return a list of all direct challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = CreateChallenge.objects.get(id=user_id)
                serializer = CreateNewChallengeSerializer(user, many=True)
                return Response({"data": serializer.data})
            user = CreateChallenge.objects.all()
            serializer = CreateNewChallengeSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of new created challenge"})
