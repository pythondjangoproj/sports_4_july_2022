"""import required module"""
from rest_framework.views import APIView
from IGL_account.models import User
from .models import TournamentSetupIn
from .serializers import UserOtpSerializer, AdminLoginSerializer, AdminProfileSerializer, AdminRegistrationSerializer, TournamentSetupSerializer
from django.contrib.auth import authenticate
from django.contrib.auth.models import Group
from rest_framework.response import Response
import logging
from IGL_account.renderers import UserRenderer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from rest_framework import generics
import random
from iconApi.settings import default
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
# Create your views here.


logger = logging.getLogger(__name__)


# Generate Token Manually
def get_tokens_for_user(user):
    """Generate Token Manually"""
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


# to perform send OTP operation for registered IGL user
class UserOtpView(APIView):
    """To perform the Otp operation sending on mail"""
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            email = request.data.get('email')
            if User.objects.filter(email=email).exists():
                serializer = UserOtpSerializer(data=request.data)
                if serializer.is_valid():
                    email = serializer.data.get('email')
                    otp = random.randint(100000, 999999)
                    link = str(otp)
                    plaintext = "test email"
                    htmly = get_template('Admin_app/verification-mail.html')
                    otp_link = {'link': link}
                    subject, from_email, to = 'One time password', default.EMAIL_HOST_USER, email
                    text_content = plaintext
                    html_content = htmly.render(otp_link)
                    msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
                    msg.attach_alternative(html_content, "text/html")
                    msg.send()
                    return Response({"status": True, "otp": otp}, status=status.HTTP_200_OK)
            else:
                return Response({'message': 'Unable to send OTP with given credential'},
                                status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to send OTP with given credential"}, status=status.HTTP_404_NOT_FOUND)


class AdminLoginView(APIView):
    """to perform login operation for registered Admin user"""
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            user = User.objects.get(email=request.data.get('email'))
            if user.groups.all().exists():
                serializer = AdminLoginSerializer(data=request.data)
                if serializer.is_valid():
                    email = serializer.data.get('email')
                    password = serializer.data.get('password')
                    user = authenticate(email=email, password=password)
                    if user is not None:
                        token = get_tokens_for_user(user)
                        return Response({'token': token, 'msg': 'Login Success'}, status=status.HTTP_200_OK)
                    else:
                        return Response({'errors': {'non_field_errors': ['Email or Password is not Valid']}},
                                        status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"status": False, "error": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to perform login operation with given credential"}, status=status.HTTP_404_NOT_FOUND)


# To fetch the IGL User details
class AdminProfileView(APIView):
    """To fetch the Admin User details"""
    renderer_classes = [UserRenderer]
    permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        try:
            serializer = AdminProfileSerializer(request.user)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the Admin user Record"}, status=status.HTTP_404_NOT_FOUND)


class AdminRegistrationView(APIView):
    """To perform the Admin user registration"""
    renderer_classes = [UserRenderer]
    permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:
            get_group = request.user.groups.all().values_list('name', flat=True)
            if 'SUPER ADMIN' in get_group:
                group_name = request.data.get('group')
                serializer = AdminRegistrationSerializer(data=request.data)
                if serializer.is_valid():
                    user = serializer.save()
                    add_group = Group.objects.get(name=group_name)
                    user.groups.add(add_group)
                    token = get_tokens_for_user(user)
                    return Response({'token': token, 'msg': 'Registration Successful'}, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({'msg': 'Request user is not Super Admin'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to registered the user details"}, status=status.HTTP_400_BAD_REQUEST)


class TournamentSetupAPI(generics.GenericAPIView):
    # permission_classes = [IsAuthenticated]
    serializer_class = TournamentSetupSerializer

    def post(self, request, format=None):
        try:
        # if request.user.groups.all().exists:
            serializer = TournamentSetupSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({'msg': 'Tournament setup successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
            return Response({'msg': serializer.errors}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({'msg': 'Unable to create Tournament setup'}, status=status.HTTP_404_NOT_FOUND)

    def get(self, request, format=None):
        data = TournamentSetupIn.objects.all()
        serializer = TournamentSetupSerializer(data, many=True)
        return Response({'msg': serializer.data}, status=status.HTTP_200_OK)
