"""Import required module"""
from rest_framework import serializers
from IGL_account.models import User
from .models import TournamentSetupIn, TournamentFormateIn, TournamentLengthIn, MyTimezoneTableIn


class AdminRegistrationSerializer(serializers.ModelSerializer):
    """ We are writing this because we need confirm password field in our registration Request """
    confirm_password = serializers.CharField(style={'input_type': 'password'}, write_only=True)

    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name', 'mobile_number', 'email', 'IGL_Username', 'password',
                  'confirm_password']
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def validate(self, attrs):
        """ Validating Password and Confirm Password while Registration"""
        password = attrs.get('password')
        confirm_password = attrs.get('confirm_password')
        if password != confirm_password:
            raise serializers.ValidationError("Password and Confirm Password doesn't match")
        return attrs

    def create(self, validate_data):
        return User.objects.create_admin(**validate_data)


class AdminLoginSerializer(serializers.ModelSerializer):
    """ A class AdminLoginSerializer Serializer is used for  AdminLogin Model """
    email = serializers.EmailField(max_length=255)

    class Meta:
        model = User
        fields = ['email', 'password']


class UserOtpSerializer(serializers.ModelSerializer):
    """ create UserOtpSerializer for sending otp to mail"""
    email = serializers.EmailField(max_length=255)

    class Meta:
        model = User
        fields = ['email', ]


class AdminProfileSerializer(serializers.ModelSerializer):
    """ create AdminProfileSerializer for serialized admin profile details"""
    groups = serializers.SerializerMethodField()

    class Meta:
        """ Metaclass is used for changed the behaviour of Your User Model fields"""
        model = User
        fields = ['id', 'last_login', 'is_superuser', 'is_staff', 'is_active', 'date_joined', 'first_name', 'last_name',
                  'mobile_number', 'IGL_Username', 'is_varified', 'terms_and_condition_agreement',
                  'code_of_conduct_agreement', 'email', 'profile_image', 'groups']

    def get_groups(self, obj):
        group = obj.groups.all()
        for name in group:
            return str(name)

    # def get_user_permissions(self, obj):
    #     permissions = obj.get_group_permissions()
    #     print('permisiionsss0', permissions)
    #     return list(permissions)


class TournamentFormateSerializer(serializers.ModelSerializer):

    class Meta:
        model = TournamentFormateIn
        fields = ('id', 'type')


class MyTableZoneSerializer(serializers.ModelSerializer):

    class Meta:
        model = MyTimezoneTableIn
        fields = ('id', 'tz_name')


class TournamentLengthSerializer(serializers.ModelSerializer):

    class Meta:
        model = TournamentLengthIn
        fields = ('id', 'hour')


class TournamentSetupSerializer(serializers.ModelSerializer):

    class Meta:
        model = TournamentSetupIn
        fields = ('id', 'name', 'tournament_host', 'platform', 'game', 'highest_index_eligible', 'team_member_only',
                  'Tournament_start_date', 'Tournament_start_time', 'timezone', 'checked_in_at', 'registration_open_date',
                  'registration_close_date', 'team_event', 'max_players_team', 'tournament_structure', 'max_player_participants',
                  'tournament_open_to', 'entry_fee', 'third_place_game', 'participants_placement', 'tournament_length',
                  'points_per_kill', 'first_place', 'second_place', 'third_place', 'fourth_place', 'fifth_place',
                  'first_prize_image', 'second_prize_image', 'third_prize_image')
