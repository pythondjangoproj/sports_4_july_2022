"""import required module"""
from django.shortcuts import render
from rest_framework.views import APIView
from .serializers import UserPlatformSerializer, UserGameSerializer, UserMatchParticipantSerializer, \
    GetUserSubmitSerializer, IGLNotificationSerializer, GlobalIndexHierarchySerializer, \
    GlobalIndexSerializer, PGIUserSubmitSerializer, UserIGLNotificationSerializer, UserTrophyCaseSerializer, \
    CompleteProfileSerializer, CreateProfileSerializer, CompleteProfileUpdateSerializer
from .models import UserPlatform, UserGame, UserMatchParticipant, GetUserSubmit, IGLNotification, \
    GlobalIndexHierarchy, GlobalIndex, PGIUserSubmit, UserIGLNotification, UserTrophyCase, CompleteProfile, \
    FriendRequest, FriendList
from rest_framework.response import Response
from rest_framework import generics
import logging
from IGL_account.renderers import UserRenderer
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.decorators import api_view
from games.models import Platform, Game
from IGL_account.models import User
from datetime import date
logger = logging.getLogger(__name__)


# Create your views here.


class UserPlatformAPI(generics.GenericAPIView):
    serializer_class = UserPlatformSerializer

    def post(self, request):
        """Create List of record for UserPlatform
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = UserPlatformSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('User Platform Information incoming!', e)
            return Response({"message": "Unable to create the user platform"})

    def get(self, request, pk=None):
        """return a list of all Match for specific UserPlatform
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserPlatform id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = UserPlatform.objects.get(id=user_id)
                serializer = UserPlatformSerializer(user)
                return Response({"data": serializer.data})
            user = UserPlatform.objects.all()
            serializer = UserPlatformSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of user platform "})


class UserGameAPI(generics.GenericAPIView):
    serializer_class = UserGameSerializer

    def post(self, request):
        """Create List of record for UserGame
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = UserGameSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('User game Information incoming!', e)
            return Response({"message": "Unable to create user Game"})

    def get(self, request, pk=None):
        """return a list of all Match for specific UserGame
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserGame id.
            """

        user_id = pk
        try:
            if user_id is not None:
                user = UserGame.objects.get(id=user_id)
                serializer = UserGameSerializer(user)
                return Response({"data": serializer.data})
            user = UserGame.objects.all()
            serializer = UserGameSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('user game Information incoming!', e)
            return Response({"message": "Unable to create Game for registered user"})


class UserMatchParticipantAPI(generics.GenericAPIView):
    serializer_class = UserMatchParticipantSerializer

    def post(self, request):
        """Create List of record for UserMatchParticipant
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = UserMatchParticipantSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('User match Information incoming!', e)
            return Response({"message": "Unable to create match for user"})

    def get(self, request, pk=None):
        """return a list of all Match for specific UserMatchParticipant
             :parm request:object to pass state,WHEN page/url requested by user.
                parm pk:pass to UserMatchParticipant id.
                    """
        user_id = pk
        try:
            if user_id is not None:
                user = UserMatchParticipant.objects.get(id=user_id)
                serializer = UserMatchParticipantSerializer(user)
                return Response({"data": serializer.data})
            user = UserMatchParticipant.objects.all()
            serializer = UserMatchParticipantSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to Get the details of user match participants"})


class UserTrophyCaseAPI(generics.GenericAPIView):
    serializer_class = UserTrophyCaseSerializer

    def get(self, request, pk=None):
        """return a list of all UserTrophyCase for specfic UserTrophyCase
                :parm request:object to pass state,WHEN page/url requested by user.
                parm pk:pass to UserTrophyCase id.
                """
        user_id = pk
        try:
            if user_id is not None:
                user = UserTrophyCase.objects.get(id=user_id)
                serializer = UserTrophyCaseSerializer(user)
                return Response({"data": serializer.data})
            user = UserTrophyCase.objects.all()
            serializer = UserTrophyCaseSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('user trophy Information incoming!', e)
            return Response({"message": "Unable to get the UserTrophyCase details"})

    def post(self, request):
        """Create List of record for UserTrophyCase
              :parm request:object to pass to state when request page/url requested the user
              """
        try:
            serializer = UserTrophyCaseSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('user trophy Information incoming!', e)
            return Response({"message": "Unable to create the UserTrophyCaseSerializer details"})

    def delete(self, request, pk):
        """delete a single record for BadgesCategory,when request page/url requested the user
                      :params pk pass the  UserTrophyCase record id"""

        usercase = UserTrophyCase(pk)
        usercase.delete()
        return Response({"msg": "UserTrophyCase  is deleted"})


class GetUserSubmitAPI(generics.GenericAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [IsAuthenticated]
    serializer_class = GetUserSubmitSerializer

    def post(self, request):
        """Create List of record for GetUserSubmit
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = GetUserSubmitSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('User Platform Information incoming!', e)
            return Response({"message": "Unable to submit profile details of user"})

    def get(self, request, pk=None):
        """return a list of all Match for specific user profile
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserDetails id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = GetUserSubmit.objects.get(id=user_id)
                serializer = GetUserSubmitSerializer(user)
                return Response({"data": serializer.data})
            user = GetUserSubmit.objects.all()
            serializer = GetUserSubmitSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to get profile details of user "})


class IGLNotificationAPI(generics.GenericAPIView):
    serializer_class = IGLNotificationSerializer

    def post(self, request):
        """Create List of record for IGLNotification
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = IGLNotificationSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as ex:
            print(str(ex))

    def get(self, request, pk=None):
        """return a list of all Match for specific user IGLNotification
        :parm request:object to pass state,WHEN page/url requested by user.
        parm pk:pass to UserDetails id.
        """
        user_id = pk
        if user_id is not None:
            user = IGLNotification.objects.get(id=user_id)
            serializer = IGLNotificationSerializer(user)
            return Response({"data": serializer.data})
        user = IGLNotification.objects.all()
        serializer = IGLNotificationSerializer(user, many=True)
        return Response({"data": serializer.data})

    def delete(self, request, pk):
        """delete a single record for IGLNotification,when request page/url requested the user
            :params pk pass the  IGLNotification record id"""
        game = IGLNotification(pk)
        game.delete()
        return Response({"msg": "IGL notification is deleted"})


class GlobalIndexHierarchyAPI(generics.GenericAPIView):
    serializer_class = GlobalIndexHierarchySerializer

    def post(self, request):
        """Create List of record for GlobalIndexHierarchyA
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = GlobalIndexHierarchySerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as ex:
            print(str(ex))

    def get(self, request, pk=None):
        """return a list of all Match for specific user GlobalIndexHierarchy
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserDetails id.
            """
        user_id = pk
        if user_id is not None:
            user = GlobalIndexHierarchy.objects.get(id=user_id)
            serializer = GlobalIndexHierarchySerializer(user)
            return Response({"data": serializer.data})
        user = GlobalIndexHierarchy.objects.all()
        serializer = GlobalIndexHierarchySerializer(user, many=True)
        return Response({"data": serializer.data})


class GlobalIndexAPI(generics.GenericAPIView):
    serializer_class = GlobalIndexSerializer

    def post(self, request):
        """Create List of record for GlobalIndex
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = GlobalIndexSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as ex:
            print(str(ex))

    def get(self, request, pk=None):
        """return a list of all Match for specific user GlobalIndex
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to GlobalIndex id.
            """
        user_id = pk
        if user_id is not None:
            user = GlobalIndex.objects.filter(user_id=user_id)
            serializer = GlobalIndexSerializer(user, many=True)
            return Response({"data": serializer.data})
        user = GlobalIndex.objects.all()
        serializer = GlobalIndexSerializer(user, many=True)
        return Response({"data": serializer.data})

    def delete(self, request, pk):
        """delete a single record for GlobalIndex,when request page/url requested the user
                      :params pk pass the  GlobalIndexA record id"""

        usercase = GlobalIndex(pk)
        usercase.delete()
        return Response({"msg": "global index is deleted"})


class PGIUserSubmitAPI(generics.GenericAPIView):
    serializer_class = PGIUserSubmitSerializer

    def post(self, request):
        """Create List of record for PGIUserSubmit
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = PGIUserSubmitSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon Information incoming!', e)
            return Response({"message": "Unable to create USER platform game and icon"})

    def get(self, request, pk=None):
        """return a list of all Match for specific user PGIUserSubmit
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to PGIUserSubmit id.
            """
        user_id = pk
        try:
            if user_id is not None:
                user = PGIUserSubmit.objects.get(id=user_id)
                serializer = PGIUserSubmitSerializer(user)
                return Response({"data": serializer.data})
            user = PGIUserSubmit.objects.all()
            serializer = PGIUserSubmitSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon Information incoming!', e)
            return Response({"message": "Unable to get the user submit details"})


class UserIglNotificationViewAPI(APIView):
    # renderer_classes = [UserRenderer]
    serializer_class = UserIGLNotificationSerializer

    def get(self, request, pk=None):
        """return a list of all Match for specific user UserIglNotification
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to UserIglNotification
            """
        user_id = pk
        if user_id is not None:
            user = UserIGLNotification.objects.filter(user_id=user_id)
            serializer = UserIGLNotificationSerializer(user, many=True)
            return Response({"data": serializer.data})
        user = UserIGLNotification.objects.all()
        serializer = UserIGLNotificationSerializer(user, many=True)
        return Response({"data": serializer.data})

    def post(self, request):
        """Create List of record for UserIglNotification
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = UserIGLNotificationSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except:
            return Response({"message": "Unable to create IGL user_notification"})

    def delete(self, request, pk):
        """delete a single record for UserIglNotification,when request page/url requested the user
            :params pk pass the  UserIglNotification record id"""
        game = UserIGLNotification(pk)
        game.delete()
        return Response({"msg": "IGL user notification is deleted"})


class CompleteProfileAPI(generics.GenericAPIView):
    serializer_class = CreateProfileSerializer

    # permission_classes = [IsAuthenticated]

    def post(self, request):
        """Create List of record for Match
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = CreateProfileSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to complete user profile "})

    def get(self, request, pk=None):
        """return a list of all Match for specific Match
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to Match id.
            """
        user_id = pk
        try:
            if user_id is not None:
                user = CompleteProfile.objects.filter(user_id=user_id)
                serializer = CompleteProfileSerializer(user, many=True)
                return Response({"data": serializer.data})
            user = CompleteProfile.objects.all()
            serializer = CompleteProfileSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get user complete profile details"})


class CompleteProfileUpdateAPI(generics.GenericAPIView):
    serializer_class = CompleteProfileUpdateSerializer

    # permission_classes = [IsAuthenticated]

    def post(self, request):
        """Create List of record for Match
                :parm request:object to pass to state when request page/url requested the user
                 """
        try:
            serializer = CompleteProfileUpdateSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to complete user profile "})

    def get(self, request, pk=None):
        """return a list of all Match for specific Match
                :parm request:object to pass state,WHEN page/url requested by user.
                parm pk:pass to Match id.
                """
        user_id = pk
        try:
            if user_id is not None:
                user = CompleteProfile.objects.filter(user_id=user_id)
                serializer = CompleteProfileUpdateSerializer(user, many=True)
                return Response({"data": serializer.data})
            user = CompleteProfile.objects.all()
            serializer = CompleteProfileUpdateSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get user complete profile details"})

    def patch(self, request, pk=id):
        """update a list of record for TrophyCategory,when request page/url requested the user
                       :params pk pass the  TrophyCategory record id"""
        user_id = pk
        try:
            if user_id is not None:
                update_platform = request.data['update_platform']
                remove_platform = request.data['remove_platform']
                update_game = request.data['update_game']
                remove_game = request.data['remove_game']
                for profile in CompleteProfile.objects.filter(user_id=user_id):
                    if update_platform or remove_platform or update_game or remove_game:
                        try:
                            for platform in update_platform:
                                platform_id = Platform.objects.get(id=platform)
                                profile.platform.add(platform_id.id)

                            for platform in remove_platform:
                                platform_id = Platform.objects.get(id=platform)
                                profile.platform.remove(platform_id.id)

                        except Exception as e:
                            logging.info('Information incoming!', e)
                            return Response({"message": "Please enter valid platform details"})

                        try:
                            for game in update_game:
                                game_id = Game.objects.get(id=game)
                                profile.games.add(game_id.id)

                            for game in remove_game:
                                game_id = Game.objects.get(id=game)
                                profile.games.remove(game_id.id)

                        except Exception as e:
                            logging.info('Information incoming!', e)
                            return Response({"message": "Please enter valid game details"})

                        return Response({"message": "Profile is Successfully Updated"})

                    else:
                        return Response({"message": "Profile not Updated"})

        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to update user details"})


# @api_view(['POST'])
# def get(request, formate=None):
#     email = request.data.get('email')
#     recipient = User.objects.filter(email=email).values_list('id', flat=True)
#     recipient_id = recipient[0]
#     model = FriendRequest.objects.get_or_create(sender=request.user, receiver_id=recipient_id)
#     return Response({'msg': 'Friend Request sent successfully'})


@api_view(['POST'])
def get(request, formate=None):
    email = request.data.get('email')
    user = request.user
    user_id = user.id
    user_name = user.first_name
    recipient = User.objects.filter(email=email).values_list('id', flat=True)
    recipient_id = recipient[0]

    obj = FriendRequest.objects.all().filter(sender=request.user, receiver_id=recipient_id)
    if not obj:
        model = FriendRequest.objects.get_or_create(sender=request.user, receiver_id=recipient_id)
        IGLNotificationQuery = IGLNotification.objects.create(status=False, date=date.today(),
                                                              sender=user_name,
                                                              type_of_notification="Friend Request",
                                                              message=f"{user_name} sent friend request")
        IGLNotificationQuery.save()
        IGLNotification_id = IGLNotificationQuery.id
        UserIGLNotificationQueryset = UserIGLNotification.objects.create(user_id_id=user_id,
                                                                         user_notification_id=IGLNotification_id)
        UserIGLNotificationQueryset.save()

        return Response({'msg': f'{user_name} sent friend request successfully'})
    else:
        return Response({'msg': 'Friend request already sent'})



@api_view(['POST'])
def add_or_remove_friend(request, format=None):
    operation = request.data.get('operation', '')
    new_friend_email = request.data.get('email', '')
    user = User.objects.filter(email=request.user).values('id')[0]
    print("user", user)
    new_friend = User.objects.values('id').filter(email=new_friend_email)[0]
    if operation == 'add':

        fq = FriendRequest.objects.filter(sender_id=user['id'], receiver_id=new_friend['id'])

        FriendList.make_friend(user['id'], new_friend['id'])
        FriendList.make_friend(new_friend['id'], user['id'])
        fq.delete()
        return Response({"msg": " Friend accepted successfully"})
    elif operation == 'remove':
        FriendList.lose_friend(user['id'], new_friend['id'])
        FriendList.lose_friend(new_friend['id'], user['id'])
        return Response({"msg": " Friend deleted successfully"})
