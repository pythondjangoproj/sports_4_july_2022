from django.contrib import admin
from profile_app.models import UserPlatform, UserGame, UserMatchParticipant, GetUserSubmit, \
    IGLNotification, GlobalIndexHierarchy, GlobalIndexCriteria, GlobalIndex, PGIUserSubmit, UserIGLNotification, \
    UserTrophyCase, CompleteProfile, FriendList, FriendRequest


# Register your models here.
class UserPlatformAdmin(admin.ModelAdmin):
    list_display = ['user_id']


admin.site.register(UserPlatform, UserPlatformAdmin)


class UserGameAdmin(admin.ModelAdmin):
    list_display = ['gammer_tag']


admin.site.register(UserGame, UserGameAdmin)


class UserMatchParticipantAdmin(admin.ModelAdmin):
    list_display = ['usermatchparticipant_id']


admin.site.register(UserMatchParticipant, UserMatchParticipantAdmin)

admin.site.register(UserTrophyCase)


class UserGetUserSubmitAdmin(admin.ModelAdmin):
    list_display = ['igl_username']


admin.site.register(GetUserSubmit, UserGetUserSubmitAdmin)


class IGL_Notification_Admin(admin.ModelAdmin):
    list_display = (
        'type_of_notification',)


admin.site.register(IGLNotification, IGL_Notification_Admin)


class GlobalIndexHierarchyAdmin(admin.ModelAdmin):
    list_display = ['start_index', 'end_index', 'global_index']


class GlobalIndexCriteriaAdmin(admin.ModelAdmin):
    list_display = ['action', 'point', 'rule']


@admin.register(GlobalIndex)
class GlobalIndex(admin.ModelAdmin):
    list_display = ['id', 'user_id', 'igl_global_index']


admin.site.register(GlobalIndexHierarchy, GlobalIndexHierarchyAdmin)
admin.site.register(GlobalIndexCriteria, GlobalIndexCriteriaAdmin)


class PGIUserSubmitAdmin(admin.ModelAdmin):
    list_display = ['user_id']


admin.site.register(PGIUserSubmit, PGIUserSubmitAdmin)


class UserIGL_Notification_Admin(admin.ModelAdmin):
    list_display = (
        'user_id', 'user_notification',)


admin.site.register(UserIGLNotification, UserIGL_Notification_Admin)


class CompleteProfileAdmin(admin.ModelAdmin):
    list_display = ['igl_username']


admin.site.register(CompleteProfile, CompleteProfileAdmin)
admin.site.register(FriendList)
admin.site.register(FriendRequest)
