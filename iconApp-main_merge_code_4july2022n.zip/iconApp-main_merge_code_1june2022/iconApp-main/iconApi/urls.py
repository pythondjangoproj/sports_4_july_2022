from django.contrib import admin
from django.urls import path, include

# from challenge.urls import router as ChallengeRouter
# from auction.urls import router as AuctionRouter
# from rest_framework import routers
# api_router = routers.DefaultRouter()
# api_router.registry.extend(ChallengeRouter.registry)
# api_router.registry.extend(AuctionRouter.registry)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('AdminApi/', include('Admin_app.urls')),
    path('api/user/', include('IGL_account.urls')),
    path('games/api/', include('games.urls')),
    path('icon/api/', include('icon.urls')),
    path('profile/api/', include('profile_app.urls')),
    path('memberships/', include('payments.urls', namespace='memberships')),
    path('accounts/', include('allauth.urls')),
    # path('api-auth/', include('rest_framework.urls')),
    # path("root_api/", include(api_router.urls)),
    path('challenge_api/', include('challenge.urls')),
]
from django.conf import settings
from django.conf.urls.static import static

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL,
                          document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
