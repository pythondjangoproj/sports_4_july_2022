from .default import *

INSTALLED_APPS += ('icon', 'games', 'IGL_account', 'profile_app', 'Admin_app', 'payments', 'challenge', 'auction',)

# REST_FRAMEWORK = {
#     'DEFAULT_PERMISSION_CLASSES': [
#         'rest_framework.permissions.IsAuthenticated',
#
#     ],
#     'DEFAULT_AUTHENTICATION_CLASSES': (
#         'rest_framework.authentication.SessionAuthentication',
#     ),
#
#     'COERCE_DECIMAL_TO_STRING': False
#
# }


# App specific config
DEFAULT_TOURNAMENT_STATUS = 1
DEFAULT_PARTICIPANT_TYPE = 1
DEFAULT_REGISTRATION_STATUS = 1
DEFAULT_CHALLENGE_STATUS = 1

CHALLENGE_ACCEPTED_STATUS = 2
CHALLENGE_REFUSED_STATUS = 3
CHALLENGE_CANCELED_STATUS = 4

AUCTION_DEFAULT_CATEGORY = 1
RAFFLE_DEFAULT_CATEGORY = 1

