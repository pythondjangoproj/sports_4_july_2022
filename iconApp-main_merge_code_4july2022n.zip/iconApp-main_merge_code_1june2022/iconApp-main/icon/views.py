"""import required module"""
from django.shortcuts import render
from rest_framework.response import Response
from IGL_account.models import User
from .serializer import IconSerializer, IconTeamSerializer, IconTeamMemberSerializer
from rest_framework import generics
from .models import Icon, IconTeam, IconTeamMember
import logging

logger = logging.getLogger(__name__)


# Create your views here.

class IconAPI(generics.GenericAPIView):
    serializer_class = IconSerializer

    def post(self, request):
        """Create List of record for Icon
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = IconSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon Information incoming!', e)
            return Response({"message": "Unable to create icon"})

    def get(self, request, pk=None):
        """return a list of all Icon for specfic Icon
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to Icon id.
             """
        user_id = pk
        try:
            if user_id is not None:
                user = Icon.objects.get(id=user_id)
                serializer = IconSerializer(user)
                return Response({"data": serializer.data})
            user = Icon.objects.all()
            serializer = IconSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon Information incoming!', e)
            return Response({"message": "Unable to get the Icon details"})


class IconTeamAPI(generics.GenericAPIView):
    serializer_class = IconTeamSerializer

    def post(self, request):
        """Create List of record for IconTeam
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = IconTeamSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon Team Information incoming!', e)
            return Response({"message": "Unable to create the Icon team details"})

    def get(self, request, pk=None):
        """return a list of all IconTeam for specfic IconTeam
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to IconTeam id.
            """
        try:
            user = IconTeam.objects.all()
            serializer = IconTeamSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon Team Information incoming!', e)
            return Response({"message": "Unable to find Icon team details"})


class IconTeamMemberAPI(generics.GenericAPIView):
    serializer_class = IconTeamMemberSerializer

    def post(self, request):
        """Create List of record for IconTeamMember
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = IconTeamMemberSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon team member Information incoming!', e)
            return Response({"message": "Unable to update the Icon Team member"})

    def get(self, request, pk=None):
        """return a list of all IconTeamMember for specific IconTeamMember
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to IconTeamMember id.
            """

        user_id = pk
        try:
            if user_id is not None:
                user = IconTeamMember.objects.get(id=user_id)
                serializer = IconTeamMemberSerializer(user)
                return Response({"data": serializer.data})
            user = IconTeamMember.objects.all()
            serializer = IconTeamMemberSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Icon team member Information incoming!', e)
            return Response({"message": "Unable to find Icon team member details"})
