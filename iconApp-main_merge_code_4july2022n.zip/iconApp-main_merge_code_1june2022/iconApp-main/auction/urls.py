from rest_framework import routers
from django.urls import path
from auction.views import AuctionViewSet, BidViewSet, RaffleViewSet, RafflePurchaseViewSet

router = routers.DefaultRouter()
router.register('auctions', AuctionViewSet)
router.register('bids', BidViewSet)
router.register('raffles', RaffleViewSet)
router.register('raffle_purchases', RafflePurchaseViewSet)
