from django.contrib import admin

from .models import Auction, AuctionCategory, Bid, RaffleCategory, Raffle, RafflePurchase


class AuctionAdmin(admin.ModelAdmin):
    list_display = ['name', 'total_bids', 'highest_bid']


class BidAdmin(admin.ModelAdmin):
    list_display = ['auction', 'bidder', 'amount', 'is_highest_bid']


class RaffleAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'total_purchases']


class RafflePurchaseAdmin(admin.ModelAdmin):
    list_display = ['raffle', 'quantity', 'total_cost', ]


admin.site.register(AuctionCategory)
admin.site.register(Auction, AuctionAdmin)
admin.site.register(Bid, BidAdmin)
admin.site.register(RaffleCategory)
admin.site.register(Raffle, RaffleAdmin)
admin.site.register(RafflePurchase, RafflePurchaseAdmin)
